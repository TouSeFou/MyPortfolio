// src/react-simple-maps.d.ts
declare module "react-simple-maps";
